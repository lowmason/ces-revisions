The files in this archive contain information used during the seasonal adjustment of 
Current Employment Statistics (CES) data series. 

1. USER-DEFINED REGRESSION FILES (or "DUMMY" files)
The CES program�s current implementation of seasonal adjustment controls for several 
non-economic calendar related fluctuations in the estimates. This is done with the 
inclusion of user-defined regression (or "dummy") variables. More information about 
specific calendar-related fluctuations in CES data is available on the BLS website. 
Please visit www.bls.gov/osmr/research-papers/1996/pdf/st960190.pdf for a 
detailed explanation of the 4 vs. 5 week adjustment. Also, visit 
www.bls.gov/ces/publications/length-pay-period.htm to learn about the length of 
pay adjustment. 

The following dummy files are used in the seasonal adjustment of CES estimates:

Fdum8606.dat -- treats the 4 vs. 5 week effect
Fdumpc96.dat -- treats the 4 vs. 5 week effect plus a special adjustment for the 
        presence/absence of poll workers in local government
Fdumpcw6.dat -- treats the 4 vs. 5 week effect plus a special adjustment for the 
        presence/absence of poll workers in local government (used with 
        women employees series only)
Fdumw96.dat -- treats the 4 vs. 5 week effect plus a special adjustment for the 
		presence/absence of an annual increase in postal employment in 
		December (Note: If this file is used, it is only used with the U.S. 
		Postal Service series, AE9091912000.) 
Fdumel06.dat -- treats the Easter/Labor Day adjustment
Fdumel96.dat -- treats the 4 vs. 5 week effect plus the Easter/Labor Day adjustment
Dumlp06.dat -- treats the 10/11 day effect
Dumlpel6.dat -- treats the 10/11 day effect plus the Easter/Labor Day adjustment

The dummy files are simple text files which can be viewed and edited with a text 
editor such as TextPad, Wordpad, or Notepad. These files have been structured to 
serve as input for X-13ARIMA-SEATS running in an UNIX environment. When running 
X-13ARIMA-SEATS in DOS, the name of the dummy file must be eight characters or less. 
This is a limitation of DOS, not X-13ARIMA-SEATS. 

The dummy values are usually 1 and 0, with weights assigned so that the effect over 
a 10-year period sums to zero. More information about the dummy variables used by the 
CES program during seasonal adjustment and more technical information on the CES 
seasonal adjustment process is available in the Seasonal Adjustment Technical Notes 
at www.bls.gov/web/empsit/cesseasadjtn.htm. 

2. PRIOR ADJUSTMENT FILE (prior_adjustment_file.xlsx)
In some cases the CES program will modify the not seasonally adjusted estimates 
(input data) before running X-13ARIMA-SEATS. This is done to ensure that non-seasonal 
events such as strikes are not included in the calculation of the seasonal factors. 
The file "prior_adjustment_file.xlsx" is an Excel spreadsheet containing all 
prior adjustments back to 1975. The first column contains the 14-digit BLS NAICS-based 
tabcode, the second column contains the year, and the next 12 columns represent the 
months of the year in sequential order (January through December). The file contains 
both positive and negative numbers. The positive numbers reflect a strike and are 
added to the not seasonally adjusted data before running X-13ARIMA-SEATS. The negative 
numbers reflect the buildup of employment associated with the decennial census and 
are subtracted from the not seasonally adjusted data before calculating the seasonal 
factors. To read more about the impact of strikes on CES data, visit the BLS website 
at www.bls.gov/ces/publications/strike-report.htm. More information about the 
prior adjustment file used by the CES program during seasonal adjustment is available 
in the Seasonal Adjustment Technical Notes referenced above.

The PRIOR ADJUSTMENT FILE (prior_adjustment_file.xlsx) was updated on 4/6/2012 to 
improve the internal consistency of the data in the file. Note that these changes 
DO NOT impact the creation of seasonal factors for CES data.

Prior to this update, the prior adjustment for Census workers in the federal 
government series (9091000000) was not included in the totals for higher level 
series. The impacted series are total nonfarm (0000000000), service-providing 
(0700000000), and government (9000000000). 

Since seasonal adjustment is performed at lower levels of detail there is no impact 
on the seasonally adjusted results.   

3. PREDETERMINED OUTLIERS (outliers.xlsx)
X-13ARIMA-SEATS has an automatic outlier identification feature that will detect  
outliers which have a t-statistic exceeding a predetermined critical value. In some 
cases analysts will have special knowledge about a particular industry that may 
cause them to manually identify a particular month as an outlier. When that happens, 
the outlier needs to be manually entered in the input specification file for that 
series. The file "outliers.xlsx" is a spreadsheet containing manually identified 
outliers since the last annual processing run. The first column contains the reference 
month and year in question, while the second column contains the BLS NAICS-based 
tabcode of the series chosen as an outlier. These outliers need to be manually entered 
in the REGRESSION spec of the specification file. More information about the 
specifications employed by the CES program when seasonally adjusting estimates is 
available in the Seasonal Adjustment Technical Notes referenced above.


CONTACTS: John Stewart (202)691-6555
          United States Department of Labor
          Bureau of Labor Statistics
          Office of Employment and Unemployment Statistics
          Division of Current Employment Statistics - National
          2 Massachusetts Ave. NE, Room 2845
          Washington, DC 20212
