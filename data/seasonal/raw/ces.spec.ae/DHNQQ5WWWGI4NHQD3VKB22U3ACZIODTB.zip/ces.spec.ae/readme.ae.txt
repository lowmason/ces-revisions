The files in this archive are specification files used as input to X-13ARIMA-SEATS for the 
seasonal adjustment of the Current Employment Statistics (CES) all employees data series.

An input specification file, or a "spec" file, is a text file used to specify seasonal
adjustment program operations. The spec file is composed of functional units called 
specifications (or "specs") that give X-13ARIMA-SEATS specific information about the data and 
the desired seasonal adjustment options and output. Each specification in the spec file 
controls the options for a specific function. All of the specifications employed by the CES 
program when seasonally adjusting estimates are covered in greater detail on the Seasonal
Adjustment Files and Documentation web page available at www.bls.gov/web/empsit/cesseasadj.htm.
For more technical information on the CES seasonal adjustment process, refer to the Seasonal
Adjustment section of the CES Technical Notes available at www.bls.gov/web/empsit/cestn.htm#section6e.

The CES program generally seasonally adjusts published series directly at the 3-digit NAICS-based 
level and aggregates to the higher levels. However, there are some exceptions to this rule. 
In a few of the all employees series, the CES program will seasonally adjust at a level lower
than the 3-digit NAICS-based level. In these instances, the CES program seasonally adjusts the 
3-digit series indirectly; i.e., all of the component (lower level) series are seasonally 
adjusted directly and aggregated up to the composite (3-digit) level. All series that are seasonally
adjusted directly have a file name beginning with "AE", followed by a 10-digit BLS NAICS-based tabcode. 
For example, AE1021100000.spc is the all employees spec file for oil and gas extraction. 
Series that are seasonally adjusted indirectly have a file name beginning with "CO", followed by
a 10-digit BLS NAICS-based tabcode. For example, CO1021200000.spc is the all employees 
composite spec file for mining, except oil and gas, while CO1021210000.spc, CO1021220000.spc, 
and CO1021230000.spc are the all employees component spec files for mining, except oil and gas. 
The component spec files are seasonally adjusted directly and aggregated to the composite level. 
A current list of 3-digit NAICS-based industries that are indirectly seasonally adjusted, 
along with their component series, can be found in the Seasonal Adjustment section of the 
CES Technical Notes referenced above. 

All of the input specification files end in a ".spc" file extension. Please note that 
the ".spc" extension is not recognizable by all operating systems and usually 
needs to be viewed and edited with a text editor such as TextPad, Wordpad, or Notepad. 

These files have been structured to serve as input for X-13ARIMA-SEATS running in an UNIX 
environment. When running X-13ARIMA-SEATS in DOS, the name of the spec file must be 
eight characters or less -- therefore, the name of each spec file must shortened by four 
characters. This is a limitation of DOS, not X-13ARIMA-SEATS. 


A raking procedure is used to ensure that the sum of the seasonally 
adjusted residential specialty trade contractors and seasonally adjusted nonresidential specialty
trade contractors series is consistent with the published seasonally adjusted total for 
specialty trade contractors at the 3-digit NAICS-based level. More information about the methodology used 
in the raking procedure can be found in the Seasonal Adjustment section of the CES Technical Notes
referenced above.


CONTACTS: John Stewart (202)691-6555
          United States Department of Labor
          Bureau of Labor Statistics
          Office of Employment and Unemployment Statistics
          Division of Current Employment Statistics - National
          2 Massachusetts Ave. NE, Room 4175
          Washington, DC 20212
