The files in this archive are specification files used as input to X-12-ARIMA for the 
seasonal adjustment of the Current Employment Statistics (CES) All Employees data series.

An input specification file, or a "spec" file, is a text file used to specify seasonal
adjustment program operations.  The spec file is composed of functional units called 
specifications (or "specs") that give X-12-ARIMA specific information about the data and 
the desired seasonal adjustment options and output.  Each specification in the spec file 
controls the options for a specific function.  All of the specifications employed by the CES 
Program when seasonally adjusting estimates are covered in greater detail on the Seasonal
Adjustment Files and Documentation page available at http://www.bls.gov/web/empsit/cesseasadj.htm.
For more technical information on the CES seasonal adjustment process, refer to the Seasonal
Adjustment section of the CES Technical Notes available at http://www.bls.gov/web/empsit/cestn.htm#section5e.

The CES Program generally seasonally adjusts published series directly at the 3-digit NAICS 
level and aggregates to the higher levels. However, there are some exceptions to this rule. 
In a few of the All Employees series, the CES Program will seasonally adjust at a level lower
than the 3-digit NAICS level. In these instances, the CES Program seasonally adjust the 
3-digit series indirectly; i.e., all of the component (lower level) series are seasonally 
adjusted directly and aggregated up to the composite (3-digit) level. All series that are seasonally
adjusted directly have a file name beginning with "AE", followed by a 10-digit BLS NAICS tab 
code.  For example, AE1021100000.spc is the All Employees spec file for Oil and Gas Extraction.  
Series that are seasonally adjusted indirectly have a file name beginning with "CO", followed by
a 10-digit BLS NAICS tab code.  For example, CO1021200000.spc is the All Employee composite spec file
for Coal Mining, while CO1021210000.spc, CO1021220000.spc, and CO1021230000.spc are the All Employee 
component spec files for Coal Mining.  The component spec files are seasonally adjusted directly
and aggregated to the composite level.  A current list of 3-digit NAICS industries that are 
indirectly seasonally adjusted, along with their component series, can be found in the Seasonal
Adjustment section of the CES Technical Notes available at http://www.bls.gov/web/empsit/cestn.htm#section5e. 

All of the input specification files end in a ".spc" file extension.  Please note that 
the ".spc" extension is not recognizable by all operating systems and usually 
needs to be viewed and edited with a text editor such as TextPad, Wordpad, or Notepad.  

These files have been structured to serve as input for X-12-ARIMA running in an UNIX 
environment.  When running X-12-ARIMA in DOS, the name of the spec file must be 
8 characters or less -- therefore, the name of each spec file must shortened by four 
characters.  This is a limitation of DOS, not X-12-ARIMA.  

***SPECIAL NOTE***
Concurrent with the release of the 2004 benchmark, the CES Program began producing and 
publishing employment series for residential specialty trade contractors (2023800100) and 
nonresidential specialty trade contractors (2023800200).  The two new employment series are
derived independently from the traditionally published 3-digit NAICS series specialty trade 
contractors (2023800000).  A raking procedure is used to ensure that the sum of the seasonally 
adjusted residential specialty trade contractors and seasonally adjusted nonresidential specialty
trade contractors series is consistent with the published seasonally adjusted total for 
specialty trade contractors at the 3-digit NAICS level.  The raking adjustment follows the following 
methodology:

1.  Estimates are seasonally adjusted independently for the residential and nonresidential 
    groups at the 3-digit NAICS level.
2.  The seasonally adjusted residential and nonresidential series are summed at the 3-digit NAICS
    level to get a 3-digit total.  
3.  Ratios of seasonally adjusted residential-to-total employment and seasonally adjusted 
    nonresidential-to-total employment are calculated. 
4.  The sum of the seasonally adjusted residential/non-residential series is subtracted from the 
    official 3-digit seasonally adjusted estimate for specialty trade contractors to determine 
    the amount that must be raked.
5.  The total amount that must be raked is multiplied by the ratios to determine what percentage 
    of the raked amount should be applied to the residential group and what percentage should be 
    applied to the nonresidential group.
6.  Once the seasonally adjusted residential and nonresidential groups receive their 
    proportional amount of raked employment, the two groups are aggregated again to get a 3-digit
    total.  At this point their sum should be equal to the official 3-digit seasonally adjusted 
    estimate for specialty trade contractors.


CONTACTS:  Kirk Mueller (202)691-6555
           United States Department of Labor
           Bureau of Labor Statistics
           Office of Employment and Unemployment Statistics
           Division of Current Employment Statistics
           2 Massachusetts Ave. NE, Room 4860
           Washington, DC 20212
